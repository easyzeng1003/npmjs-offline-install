@echo off
setlocal
rem Install ajv and undici from the bundled tarballs without network access.
cd /d "%~dp0"
for %%f in (tarballs\*.tgz) do call npm cache add ".\tarballs\%%~nxf" || exit /b 1
call npm install --offline --no-audit --no-fund || exit /b 1
echo Done. ajv and undici are installed in "%~dp0node_modules".
